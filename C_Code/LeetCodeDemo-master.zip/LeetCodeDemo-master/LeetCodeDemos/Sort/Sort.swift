//
//  Sort.swift
//  LeetCodeDemo
//
//  Created by reborn on 2019/12/16.
//  Copyright © 2019 reborn. All rights reserved.
//

import UIKit

protocol SorType {
    func sort(items: Array<Int>) -> Array<Int>
}





